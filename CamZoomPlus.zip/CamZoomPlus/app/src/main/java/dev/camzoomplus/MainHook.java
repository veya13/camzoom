package dev.camzoomplus;

import android.content.Context;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Process;
import android.os.SystemClock;
import android.util.Range;

import java.lang.ref.WeakReference;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * CamZoomPlus - Samsung Camera 17.0.00.43 (com.sec.android.app.camera)
 *
 * 1) Adds a 5x button to the zoom shortcut pill (Photo + normal Video).
 *    The app already ships the BACK_CAMERA_ZOOM_SHORTCUT_X5 key and its label,
 *    value (5000) and content-description tables, so we only inject the key
 *    into the list handed to the pill adapter.
 *
 * 2) Replaces the instant jump of a shortcut tap with an eased, exponential
 *    zoom ramp. Each frame goes through the same engine zoom setter that the
 *    pinch gesture and the tick slider use.
 *
 * All obfuscated names below were read from this exact build. On any other
 * build the hooks log an error and do nothing instead of crashing the camera.
 */
public class MainHook implements IXposedHookLoadPackage {

    private static final String PKG = "com.sec.android.app.camera";
    private static final String TAG = "[CamZoomPlus] ";
    private static final String EXPECTED_VERSION = "17.0.00.43";

    // ---- obfuscated names (build 17.0.00.43) ----
    private static final String C_KEY_ENUM   = "l9.j0";   // settings key enum, has BACK_CAMERA_ZOOM_SHORTCUT_*
    private static final String C_SETTING    = "l9.f0";   // settings enum, has ZOOM_VALUE
    private static final String C_PILL_ADAPT = "z9.k";    // ZoomShortcutListView adapter (dial list, all keys)
    private static final String C_LENS_VIEW  = "com.sec.android.app.camera.layer.keyscreen.zoom.lenslist.ZoomLensListView"; // the capsule: .6 1 2 3 10
    private static final String C_LENS_ITEM  = "w9.e";    // capsule item model: (int zoomValueX1000, j0 key)
    private static final String C_KEY_VALUE  = "d8.r";    // static int d(j0) -> zoom * 1000
    private static final String C_PRESENTER  = "v9.i";    // zoom presenter, h(int) = shortcut tap
    private static final String C_LISTENER_J = "v9.j";
    private static final String C_ENGINE_ZOOM = "p8.n1";  // e(float) = engine zoom setter

    // field names inside the presenter / controller
    private static final String F_PRESENTER_CAMERA_CTRL = "b"; // v9.i.b  -> p8.e0
    private static final String F_CTRL_ZOOM_MGR        = "q"; // p8.e0.q -> p8.n1
    private static final String F_PRESENTER_SETTINGS   = "d"; // v9.i.d  -> vc.j (settings store)

    private static final String KEY_X5 = "BACK_CAMERA_ZOOM_SHORTCUT_X5";

    // ---- ramp state (UI thread only) ----
    // ---- tap ramp state: the ramp runs on its own thread, decoupled from UI-thread stalls ----
    private static volatile HandlerThread sRampThread;
    private static Handler sRampHandler;
    private static Handler sMainHandler;          // created lazily: main Looper may not exist at class load
    private static volatile int sGen;                 // bumping this cancels the running ramp
    private static volatile boolean sRamping;
    private static volatile float sCurrentRatio = -1f;
    private static boolean sPassThrough;              // main thread only: replaying the stock handler
    private static final long TICK_MS = 8;            // ~125 updates per second

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
        if (!PKG.equals(lp.packageName)) return;
        try {
            Context ctx = (Context) XposedHelpers.callMethod(
                    XposedHelpers.callStaticMethod(
                            XposedHelpers.findClass("android.app.ActivityThread", null),
                            "currentActivityThread"),
                    "getSystemContext");
            String ver = ctx.getPackageManager().getPackageInfo(PKG, 0).versionName;
            if (!EXPECTED_VERSION.equals(ver)) {
                XposedBridge.log(TAG + "built for " + EXPECTED_VERSION + " but found " + ver
                        + "; hooks may not match, trying anyway");
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + "version check skipped: " + t);
        }

        hook5xButton(lp.classLoader);
        hookSmoothZoom(lp.classLoader);
        hookZoomRocker(lp.classLoader);
        hookTapAndLabels(lp.classLoader);
        hookTickSlider(lp.classLoader);
        hookReadouts(lp.classLoader);
        hookRealMaxZoom(lp.classLoader);
    }

    // =====================================================================
    // 4) 5x tap handling + 20x -> "25" label (video)
    // =====================================================================
    private static WeakReference<Object> sZoomView;

    private void hookTapAndLabels(final ClassLoader cl) {
        // remember the live ZoomView so we can reach its presenter (field "b")
        try {
            final Class<?> zoomView = XposedHelpers.findClass(
                    "com.sec.android.app.camera.layer.keyscreen.zoom.ZoomView", cl);
            XposedBridge.hookAllMethods(zoomView, "m", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam p) {
                    sZoomView = new WeakReference<>(p.thisObject);
                }
            });
        } catch (Throwable t) {
            XposedBridge.log(TAG + "zoomview capture NOT installed: " + t);
        }

        // 5x capsule tap: the stock click code does not know our key, so route it ourselves
        try {
            final Class<?> lensList = XposedHelpers.findClass(C_LENS_VIEW, cl);
            XposedBridge.hookAllMethods(lensList, "r", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam p) {
                    try {
                        if (p.args.length < 1 || p.args[0] == null) return;
                        Object btn = p.args[0];
                        Object key = XposedHelpers.callMethod(btn, "getCommandId");
                        if (key != sX5) return;
                        int value = (Integer) XposedHelpers.callMethod(btn, "getZoomValue");
                        Object zv = sZoomView != null ? sZoomView.get() : null;
                        if (zv == null) {
                            XposedBridge.log(TAG + "5x tap: no ZoomView yet, stock path");
                            return;
                        }
                        Object presenter = XposedHelpers.getObjectField(zv, "b");
                        XposedBridge.log(TAG + "5x tap -> h(" + value + ")");
                        XposedHelpers.callMethod(presenter, "h", value);
                        p.setResult(Boolean.TRUE);
                    } catch (Throwable t) {
                        XposedBridge.log(TAG + "5x tap failed, stock path: " + t);
                    }
                }
            });
            XposedBridge.log(TAG + "5x tap hook installed");
        } catch (Throwable t) {
            XposedBridge.log(TAG + "5x tap hook NOT installed: " + t);
        }

        // label only: the round "20" button shows "25"; its tap value stays 20x
        try {
            final Class<?> btnCls = XposedHelpers.findClass(
                    "com.sec.android.app.camera.layer.keyscreen.zoom.widget.ZoomLensShortcutButton", cl);
            XposedBridge.hookAllMethods(btnCls, "setText", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam p) {
                    if (p.args.length == 1 && p.args[0] instanceof Integer
                            && (Integer) p.args[0] == 20000) {
                        p.args[0] = 25000;
                    }
                }
            });
            XposedBridge.log(TAG + "25x label hook installed");
        } catch (Throwable t) {
            XposedBridge.log(TAG + "25x label hook NOT installed: " + t);
        }

        // dial row ("0.6 1 2 3 5 10 20"): relabel 20 -> 25 after the row binds; real value stays 20x
        try {
            final Class<?> dialAdapter = XposedHelpers.findClass(C_PILL_ADAPT, cl);
            XposedBridge.hookAllMethods(dialAdapter, "onBindViewHolder", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam p) {
                    try {
                        Object binding = XposedHelpers.getObjectField(p.args[0], "a");
                        Object btn = XposedHelpers.getObjectField(binding, "a");
                        int v = (Integer) XposedHelpers.callMethod(btn, "getValue");
                        if (v == 20000) XposedHelpers.callMethod(btn, "setText", "25");
                    } catch (Throwable ignored) { }
                }
            });
            XposedBridge.log(TAG + "dial 25 label hook installed");
        } catch (Throwable t) {
            XposedBridge.log(TAG + "dial 25 label hook NOT installed: " + t);
        }
    }

    // =====================================================================
    // 3) Zoom rocker (S25-style zoom slider with +/- in normal video)
    // =====================================================================
    // The rocker code ships inside the Camera app and is gated only by the feature
    // flag SUPPORT_VIDEO_MODE_ZOOM_ROCKER, which e5.f hardcodes to false unless a
    // /system/cameradata/camera-feature*.xml overrides it. Pro video (ud.u) reads the same
    // flag, so it is NOT changed globally: it is switched on only while normal-video code
    // (re.e) is running.
    private static EnumMap<?, ?> sFeatureMap;

    private void hookZoomRocker(final ClassLoader cl) {
        try {
            final Class<?> featureCls = XposedHelpers.findClass("e5.f", cl);
            final Class<?> featureEnum = XposedHelpers.findClass("e5.d", cl);
            @SuppressWarnings({"unchecked", "rawtypes"})
            final Object flag = Enum.valueOf((Class<Enum>) featureEnum, "SUPPORT_VIDEO_MODE_ZOOM_ROCKER");

            // only remember the feature map; do NOT change it globally (Pro video reads it too)
            XposedBridge.hookAllConstructors(featureCls, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam p) {
                    try {
                        sFeatureMap = (EnumMap<?, ?>) XposedHelpers.getObjectField(p.thisObject, "h");
                    } catch (Throwable t) {
                        XposedBridge.log(TAG + "feature map capture failed: " + t);
                    }
                }
            });

            // turn the flag on only while normal-video code (re.e) is asking for it
            final Class<?> normalVideo = XposedHelpers.findClass("re.e", cl);
            XC_MethodHook scoped = new XC_MethodHook() {
                @Override
                @SuppressWarnings({"unchecked", "rawtypes"})
                protected void beforeHookedMethod(MethodHookParam p) {
                    EnumMap m = (EnumMap) sFeatureMap;
                    if (m == null) return;
                    p.setObjectExtra("old", m.get(flag));
                    m.put((Enum) flag, Boolean.TRUE);
                }

                @Override
                @SuppressWarnings({"unchecked", "rawtypes"})
                protected void afterHookedMethod(MethodHookParam p) {
                    EnumMap m = (EnumMap) sFeatureMap;
                    if (m == null) return;
                    Object old = p.getObjectExtra("old");
                    if (old == null) m.remove(flag); else m.put((Enum) flag, old);
                }
            };
            for (String name : new String[]{"E2", "J1", "Z1", "b1"}) {
                XposedBridge.hookAllMethods(normalVideo, name, scoped);
            }
            XposedBridge.log(TAG + "zoom rocker hook installed (normal video only)");
        } catch (Throwable t) {
            XposedBridge.log(TAG + "zoom rocker hook NOT installed: " + t);
        }
    }

    // =====================================================================
    // 6) Bold tick at 5x on the zoom dial
    // =====================================================================
    // The dial (y9.g) draws a bold tick for every key in its shortcut list ("e", the same
    // list as ZoomView.j) and a number of thin ticks per range from a map ("f") keyed by
    // android.util.Range(prevValue, value). We add 5x to the list and split the 3x..10x range
    // into 3x..5x and 5x..10x, keeping the total tick count (so the dial length is unchanged).
    private void hookTickSlider(final ClassLoader cl) {
        try {
            final Class<?> g = XposedHelpers.findClass("y9.g", cl);
            XposedBridge.hookAllMethods(g, "f", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam p) {
                    try {
                        if (sX5 == null || sValueMap == null) return;
                        Object lo = XposedHelpers.getObjectField(p.thisObject, "e");
                        Object mo = XposedHelpers.getObjectField(p.thisObject, "f");
                        if (!(lo instanceof List) || !(mo instanceof Map)) return;
                        List<?> list = (List<?>) lo;
                        Map<?, ?> map = (Map<?, ?>) mo;
                        if (list.isEmpty() || list.contains(sX5)) return;

                        boolean has06 = false, has3 = false, has10 = false;
                        for (Object k : list) {
                            String n = ((Enum<?>) k).name();
                            if (n.endsWith("SHORTCUT_X0_6")) has06 = true;
                            if (n.endsWith("SHORTCUT_X3")) has3 = true;
                            if (n.endsWith("SHORTCUT_X10")) has10 = true;
                        }
                        if (!(has06 && has3 && has10)) return;      // Photo / normal Video only

                        Range<Integer> whole = new Range<>(3000, 10000);
                        Object cnt = map.get(whole);
                        if (!(cnt instanceof Integer)) {
                            XposedBridge.log(TAG + "dial: no 3x-10x tick count, left alone");
                            return;
                        }
                        int total = (Integer) cnt;
                        int c3 = Math.max(1, Math.round(total * 0.424f));   // ln(5/3)/ln(10/3)
                        int c5 = Math.max(1, total - c3);

                        Map<Object, Object> newMap = new HashMap<Object, Object>(map);
                        newMap.remove(whole);
                        newMap.put(new Range<>(3000, 5000), c3);
                        newMap.put(new Range<>(5000, 10000), c5);

                        List<Object> newList = new ArrayList<>(list);
                        newList.add(sX5);
                        Collections.sort(newList, (x, y) -> {
                            int vx = (Integer) XposedHelpers.callStaticMethod(sValueMap, "d", x);
                            int vy = (Integer) XposedHelpers.callStaticMethod(sValueMap, "d", y);
                            return Integer.compare(vx, vy);
                        });

                        XposedHelpers.setObjectField(p.thisObject, "e", newList);
                        XposedHelpers.setObjectField(p.thisObject, "f", newMap);
                        XposedBridge.log(TAG + "dial: 5x tick added, 3x-10x " + total + " -> " + c3 + " + " + c5);
                    } catch (Throwable t) {
                        XposedBridge.log(TAG + "dial tick inject failed: " + t);
                    }
                }
            });
            XposedBridge.log(TAG + "dial tick hook installed");
        } catch (Throwable t) {
            XposedBridge.log(TAG + "dial tick hook NOT installed: " + t);
        }
    }

    // =====================================================================
    // 7) Big zoom readout: "20.0 x" -> "25.0 x" at the video maximum (label only)
    // =====================================================================
    private void hookReadouts(final ClassLoader cl) {
        // center readout runnable (a == 0 formats and shows the number from field c)
        try {
            final Class<?> readout = XposedHelpers.findClass("v9.k", cl);
            XposedBridge.hookAllMethods(readout, "run", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam p) {
                    try {
                        if (!sVideoDial) return;
                        if (XposedHelpers.getIntField(p.thisObject, "a") != 0) return;
                        if (XposedHelpers.getIntField(p.thisObject, "c") == 20000) {
                            XposedHelpers.setIntField(p.thisObject, "c", 25000);
                        }
                    } catch (Throwable ignored) { }
                }
            });
            XposedBridge.log(TAG + "readout hook installed");
        } catch (Throwable t) {
            XposedBridge.log(TAG + "readout hook NOT installed: " + t);
        }
        // the magnifier rocker's own readout
        try {
            final Class<?> rocker = XposedHelpers.findClass(
                    "com.sec.android.app.camera.shootingmode.common.zoomrocker.ZoomRockerView", cl);
            XposedBridge.hookAllMethods(rocker, "f", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam p) {
                    if (sVideoDial && p.args.length == 1 && p.args[0] instanceof Integer
                            && (Integer) p.args[0] == 20000) {
                        p.args[0] = 25000;
                    }
                }
            });
            XposedBridge.log(TAG + "rocker readout hook installed");
        } catch (Throwable t) {
            XposedBridge.log(TAG + "rocker readout hook NOT installed: " + t);
        }
    }

    // =====================================================================
    // 8) Real 25x in normal video
    // =====================================================================
    // p8.n1.a(lens) returns the maximum zoom (x1000) for the current recording resolution; video
    // returns 20000. Every zoom control (dial, rocker, pinch, shortcut list) reads it, and
    // ZoomView.m already knows how to build a [X10, X25] list for a 25000 maximum. The camera
    // hardware may clamp requests above its own video limit, so this is an experiment.
    private static boolean sMaxLogged;

    private void hookRealMaxZoom(final ClassLoader cl) {
        try {
            final Class<?> n1c = XposedHelpers.findClass(C_ENGINE_ZOOM, cl);
            XposedBridge.hookAllMethods(n1c, "a", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam p) {
                    try {
                        if (p.args.length != 1 || p.args[0] == null) return;
                        if (!p.args[0].getClass().getName().startsWith("l9.x")) return;
                        Object r = p.getResult();
                        if (r instanceof Integer && (Integer) r == 20000) {
                            p.setResult(25000);
                            if (!sMaxLogged) {
                                sMaxLogged = true;
                                XposedBridge.log(TAG + "video max zoom raised 20x -> 25x");
                            }
                        }
                    } catch (Throwable ignored) { }
                }
            });
            XposedBridge.log(TAG + "real 25x max hook installed");
        } catch (Throwable t) {
            XposedBridge.log(TAG + "real 25x max hook NOT installed: " + t);
        }
    }

    // =====================================================================
    // 1) 5x button
    // =====================================================================
    // NOTE: the adapter constructor is 5 instructions long and gets inlined by ART,
    // so hooking it never fires. getItemCount()/onBindViewHolder() are called
    // virtually by RecyclerView and cannot be inlined, so we patch the adapter's
    // list field ("a") lazily from there.
    private static Object sX5;
    private static Class<?> sValueMap;
    private static boolean sLoggedInject;
    private static volatile boolean sVideoDial;

    private void hook5xButton(final ClassLoader cl) {
        try {
            final Class<?> keyEnum = XposedHelpers.findClass(C_KEY_ENUM, cl);
            sValueMap = XposedHelpers.findClass(C_KEY_VALUE, cl);
            @SuppressWarnings({"unchecked", "rawtypes"})
            Object x5 = Enum.valueOf((Class<Enum>) keyEnum, KEY_X5);
            sX5 = x5;

            XC_MethodHook ensure = new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam p) {
                    ensureX5(p.thisObject);
                }
            };
            for (String cn : new String[]{C_PILL_ADAPT}) {
                try {
                    Class<?> adapter = XposedHelpers.findClass(cn, cl);
                    XposedBridge.hookAllMethods(adapter, "getItemCount", ensure);
                    XposedBridge.hookAllMethods(adapter, "onBindViewHolder", ensure);
                    XposedBridge.hookAllMethods(adapter, "getItemId", ensure);
                    XposedBridge.log(TAG + "5x hook installed on " + cn);
                } catch (Throwable t) {
                    XposedBridge.log(TAG + "5x hook NOT installed on " + cn + ": " + t);
                }
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + "5x hook NOT installed: " + t);
        }
        hookCapsule(cl);
    }

    /** The visible capsule (.6 1 2 3 10): inject a 5x item right before the list is submitted. */
    private void hookCapsule(final ClassLoader cl) {
        try {
            final Class<?> view = XposedHelpers.findClass(C_LENS_VIEW, cl);
            final Class<?> item = XposedHelpers.findClass(C_LENS_ITEM, cl);
            XposedBridge.hookAllMethods(view, "t", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam p) {
                    try {
                        int li = -1;
                        for (int i = 0; i < p.args.length; i++) {
                            if (p.args[i] instanceof List) { li = i; break; }
                        }
                        if (li < 0) return;
                        List<?> orig = (List<?>) p.args[li];
                        if (orig.isEmpty() || orig.get(0) == null
                                || !orig.get(0).getClass().getName().equals(item.getName())) return;

                        boolean has2 = false, has3 = false, has5 = false;
                        StringBuilder sb = new StringBuilder();
                        for (Object o : orig) {
                            int b = XposedHelpers.getIntField(o, "b");
                            sb.append(b).append(' ');
                            if (b == 2000) has2 = true;
                            if (b == 3000) has3 = true;
                            if (b == 5000) has5 = true;
                        }
                        if (has5 || !has3 || !has2) {
                            XposedBridge.log(TAG + "capsule untouched: " + sb);
                            return;
                        }
                        Object newItem = XposedHelpers.newInstance(item, 5000, sX5);
                        List<Object> copy = new ArrayList<>(orig);
                        int at = 0;
                        for (int i = 0; i < copy.size(); i++) {
                            if (XposedHelpers.getIntField(copy.get(i), "b") < 5000) at = i + 1;
                        }
                        copy.add(at, newItem);
                        p.args[li] = copy;
                        XposedBridge.log(TAG + "capsule: 5x injected at " + at + ", was: " + sb);
                    } catch (Throwable t) {
                        XposedBridge.log(TAG + "capsule inject failed: " + t);
                    }
                }
            });
            XposedBridge.log(TAG + "capsule hook installed");
        } catch (Throwable t) {
            XposedBridge.log(TAG + "capsule hook NOT installed: " + t);
        }
    }

    private static void ensureX5(Object adapterObj) {
        try {
            Object cur = XposedHelpers.getObjectField(adapterObj, "a");
            if (!(cur instanceof List)) return;
            List<?> orig = (List<?>) cur;
            if (orig.isEmpty() || orig.contains(sX5)) return;

            boolean zoomPill = false, has06 = false, has3 = false, has20 = false, has30 = false;
            StringBuilder names = new StringBuilder();
            for (Object k : orig) {
                String n = ((Enum<?>) k).name();
                names.append(n.replace("BACK_CAMERA_ZOOM_", "")).append(' ');
                if (n.startsWith("BACK_CAMERA_ZOOM_SHORTCUT_")) zoomPill = true;
                if (n.endsWith("SHORTCUT_X0_6")) has06 = true;
                if (n.endsWith("SHORTCUT_X3")) has3 = true;
                if (n.endsWith("SHORTCUT_X20")) has20 = true;
                if (n.endsWith("SHORTCUT_X30")) has30 = true;
            }
            // Photo / normal Video lists contain both .6 and 3x. Anything else (e.g. Pro) is left alone.
            if (!(has06 && has3)) return;
            sVideoDial = has20 && !has30;      // normal video: 20x is the real maximum
            if (!zoomPill) {
                if (!sLoggedInject) XposedBridge.log(TAG + "skipped " + adapterObj.getClass().getName() + ", keys: " + names);
                sLoggedInject = true;
                return;
            }

            final List<Object> copy = new ArrayList<>(orig);
            copy.add(sX5);
            Collections.sort(copy, (x, y) -> {
                int vx = (Integer) XposedHelpers.callStaticMethod(sValueMap, "d", x);
                int vy = (Integer) XposedHelpers.callStaticMethod(sValueMap, "d", y);
                return Integer.compare(vx, vy);
            });
            XposedHelpers.setObjectField(adapterObj, "a", copy);
            XposedBridge.log(TAG + "5x injected into " + adapterObj.getClass().getName() + ". was: " + names);
        } catch (Throwable t) {
            XposedBridge.log(TAG + "5x inject failed: " + t);
        }
    }

    // =====================================================================
    // 2) Smooth zoom ramp on shortcut taps
    // =====================================================================
    private static synchronized Handler mainHandler() {
        if (sMainHandler == null) sMainHandler = new Handler(Looper.getMainLooper());
        return sMainHandler;
    }

    private static synchronized Handler rampHandler() {
        if (sRampHandler == null) {
            HandlerThread th = new HandlerThread("CamZoomPlus-ramp", Process.THREAD_PRIORITY_DISPLAY);
            th.start();
            sRampThread = th;
            sRampHandler = new Handler(th.getLooper());
        }
        return sRampHandler;
    }

    /** iOS-like ease: gentle start, strong middle, soft landing. */
    private static float ease(float t) {
        return t < 0.5f ? 4f * t * t * t : 1f - (float) Math.pow(-2f * t + 2f, 3) / 2f;
    }

    private static final class Ramp implements Runnable {
        final int gen;
        final Object zoomMgr, presenter;
        final Method handler;
        final int target;
        final float start, to;
        final long durMs, t0;

        Ramp(int gen, Object zoomMgr, Object presenter, Method handler, int target,
             float start, float to, long durMs) {
            this.gen = gen; this.zoomMgr = zoomMgr; this.presenter = presenter;
            this.handler = handler; this.target = target; this.start = start; this.to = to;
            this.durMs = durMs; this.t0 = SystemClock.uptimeMillis();
        }

        @Override
        public void run() {
            if (gen != sGen) return;                       // cancelled or superseded
            long now = SystemClock.uptimeMillis();
            float t = Math.min(1f, (now - t0) / (float) durMs);
            float ratio = (float) (start * Math.pow(to / start, ease(t)));
            sCurrentRatio = ratio;
            try {
                XposedHelpers.callMethod(zoomMgr, "e", ratio);
            } catch (Throwable th) {
                XposedBridge.log(TAG + "ramp step failed: " + th);
                sRamping = false;
                sCurrentRatio = -1f;
                sGen++;
                return;
            }
            if (t < 1f) {
                long k = (now - t0) / TICK_MS + 1;         // fixed cadence, no drift
                rampHandler().postAtTime(this, t0 + k * TICK_MS);
                return;
            }
            // finished: let the stock handler land the UI state on the main thread
            sRamping = false;
            sCurrentRatio = -1f;
            mainHandler().post(() -> {
                if (gen != sGen) return;
                sPassThrough = true;
                try {
                    XposedBridge.invokeOriginalMethod(handler, presenter, new Object[]{target});
                } catch (Throwable th) {
                    XposedBridge.log(TAG + "replay failed: " + th);
                } finally {
                    sPassThrough = false;
                }
            });
        }
    }

    private void hookSmoothZoom(final ClassLoader cl) {
        try {
            final Class<?> presenter = XposedHelpers.findClass(C_PRESENTER, cl);
            final Class<?> settingEnum = XposedHelpers.findClass(C_SETTING, cl);
            final Class<?> engineZoom = XposedHelpers.findClass(C_ENGINE_ZOOM, cl);

            @SuppressWarnings({"unchecked", "rawtypes"})
            final Object zoomValueKey = Enum.valueOf((Class<Enum>) settingEnum, "ZOOM_VALUE");

            final Method hMethod = XposedHelpers.findMethodExact(presenter, "h", int.class);

            // pinch / drag / rocker (any zoom call from another thread) takes over from the ramp
            XposedBridge.hookAllMethods(engineZoom, "e", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam p) {
                    if (sRamping && Thread.currentThread() != sRampThread) {
                        sGen++;
                        sRamping = false;
                        sCurrentRatio = -1f;
                    }
                }
            });

            XposedBridge.hookMethod(hMethod, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(final MethodHookParam p) {
                    if (sPassThrough) return;              // our own replay
                    XposedBridge.log(TAG + "shortcut tap -> " + p.args[0]);
                    if (Looper.myLooper() != Looper.getMainLooper()) return;
                    try {
                        final int target = (Integer) p.args[0];
                        final Object pres = p.thisObject;
                        final Object settings = XposedHelpers.getObjectField(pres, F_PRESENTER_SETTINGS);
                        final int curValue = (Integer) XposedHelpers.callMethod(settings, "d", zoomValueKey);
                        final Object ctrl = XposedHelpers.getObjectField(pres, F_PRESENTER_CAMERA_CTRL);
                        final Object zoomMgr = XposedHelpers.getObjectField(ctrl, F_CTRL_ZOOM_MGR);
                        if (zoomMgr == null) return;

                        final boolean busy = sRamping && sCurrentRatio > 0;
                        final float from = busy ? sCurrentRatio : curValue / 1000f;
                        final float to = target / 1000f;
                        // same value (and not mid-ramp) => let the stock code run
                        if (!busy && (target == curValue || from <= 0f || to <= 0f
                                || Math.abs(to - from) < 0.02f)) return;
                        if (from <= 0f || to <= 0f) return;

                        final double ln = Math.abs(Math.log(to / from));
                        final long dur = (long) Math.max(350, Math.min(1000, 300 + 330 * ln));
                        XposedBridge.log(TAG + "ramp " + from + " -> " + to + " in " + dur + "ms (bg thread)");

                        final int gen = ++sGen;                   // cancels any running ramp
                        sRamping = true;
                        p.setResult(null);                        // swallow the instant jump
                        rampHandler().post(new Ramp(gen, zoomMgr, pres, hMethod, target, from, to, dur));
                    } catch (Throwable t) {
                        XposedBridge.log(TAG + "smooth zoom fell back to stock: " + t);
                        // do not setResult -> stock behaviour continues
                    }
                }
            });
            XposedBridge.log(TAG + "smooth zoom hook installed (background-thread ramp)");
        } catch (Throwable t) {
            XposedBridge.log(TAG + "smooth zoom hook NOT installed: " + t);
        }
    }
}
