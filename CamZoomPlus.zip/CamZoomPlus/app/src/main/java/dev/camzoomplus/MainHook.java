package dev.camzoomplus;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * CamZoomPlus - Samsung Camera 17.0.00.43 (com.sec.android.app.camera)
 *
 * 1) Adds a 5x button to the zoom shortcut pill (Photo + normal Video).
 *    The app already ships the BACK_CAMERA_ZOOM_SHORTCUT_X5 key and its label,
 *    value (5000) and content-description tables, so we only inject the key
 *    into the list handed to the pill adapter.
 *
 * 2) Replaces the instant jump of a shortcut tap with an eased, exponential
 *    zoom ramp. Each frame goes through the same engine zoom setter that the
 *    pinch gesture and the tick slider use.
 *
 * All obfuscated names below were read from this exact build. On any other
 * build the hooks log an error and do nothing instead of crashing the camera.
 */
public class MainHook implements IXposedHookLoadPackage {

    private static final String PKG = "com.sec.android.app.camera";
    private static final String TAG = "[CamZoomPlus] ";
    private static final String EXPECTED_VERSION = "17.0.00.43";

    // ---- obfuscated names (build 17.0.00.43) ----
    private static final String C_KEY_ENUM   = "l9.j0";   // settings key enum, has BACK_CAMERA_ZOOM_SHORTCUT_*
    private static final String C_SETTING    = "l9.f0";   // settings enum, has ZOOM_VALUE
    private static final String C_PILL_ADAPT = "z9.k";    // ZoomShortcutListView adapter (dial list, all keys)
    private static final String C_LENS_VIEW  = "com.sec.android.app.camera.layer.keyscreen.zoom.lenslist.ZoomLensListView"; // the capsule: .6 1 2 3 10
    private static final String C_LENS_ITEM  = "w9.e";    // capsule item model: (int zoomValueX1000, j0 key)
    private static final String C_KEY_VALUE  = "d8.r";    // static int d(j0) -> zoom * 1000
    private static final String C_PRESENTER  = "v9.i";    // zoom presenter, h(int) = shortcut tap
    private static final String C_LISTENER_J = "v9.j";
    private static final String C_ENGINE_ZOOM = "p8.n1";  // e(float) = engine zoom setter

    // field names inside the presenter / controller
    private static final String F_PRESENTER_CAMERA_CTRL = "b"; // v9.i.b  -> p8.e0
    private static final String F_CTRL_ZOOM_MGR        = "q"; // p8.e0.q -> p8.n1
    private static final String F_PRESENTER_SETTINGS   = "d"; // v9.i.d  -> vc.j (settings store)

    private static final String KEY_X5 = "BACK_CAMERA_ZOOM_SHORTCUT_X5";

    // ---- ramp state (UI thread only) ----
    private static ValueAnimator sAnim;
    private static boolean sOurZoomCall;     // true while we call n1.e()
    private static boolean sPassThrough;     // true while we replay the original h()
    private static float sCurrentRatio = -1f;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
        if (!PKG.equals(lp.packageName)) return;
        try {
            Context ctx = (Context) XposedHelpers.callMethod(
                    XposedHelpers.callStaticMethod(
                            XposedHelpers.findClass("android.app.ActivityThread", null),
                            "currentActivityThread"),
                    "getSystemContext");
            String ver = ctx.getPackageManager().getPackageInfo(PKG, 0).versionName;
            if (!EXPECTED_VERSION.equals(ver)) {
                XposedBridge.log(TAG + "built for " + EXPECTED_VERSION + " but found " + ver
                        + "; hooks may not match, trying anyway");
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + "version check skipped: " + t);
        }

        hook5xButton(lp.classLoader);
        hookSmoothZoom(lp.classLoader);
        hookZoomRocker(lp.classLoader);
    }

    // =====================================================================
    // 3) Zoom rocker (S25-style zoom slider with +/- in normal video)
    // =====================================================================
    // The rocker code ships inside the Camera app and is gated only by the feature
    // flag SUPPORT_VIDEO_MODE_ZOOM_ROCKER, which e5.f hardcodes to false unless a
    // /system/cameradata/camera-feature*.xml overrides it. We flip it in the feature
    // map right after e5.f is constructed.
    private void hookZoomRocker(final ClassLoader cl) {
        try {
            final Class<?> featureCls = XposedHelpers.findClass("e5.f", cl);
            final Class<?> featureEnum = XposedHelpers.findClass("e5.d", cl);
            @SuppressWarnings({"unchecked", "rawtypes"})
            final Object flag = Enum.valueOf((Class<Enum>) featureEnum, "SUPPORT_VIDEO_MODE_ZOOM_ROCKER");
            XposedBridge.hookAllConstructors(featureCls, new XC_MethodHook() {
                @Override
                @SuppressWarnings({"unchecked", "rawtypes"})
                protected void afterHookedMethod(MethodHookParam p) {
                    try {
                        EnumMap map = (EnumMap) XposedHelpers.getObjectField(p.thisObject, "h");
                        map.put((Enum) flag, Boolean.TRUE);
                        XposedBridge.log(TAG + "zoom rocker flag forced ON");
                    } catch (Throwable t) {
                        XposedBridge.log(TAG + "zoom rocker flag failed: " + t);
                    }
                }
            });
            XposedBridge.log(TAG + "zoom rocker hook installed");
        } catch (Throwable t) {
            XposedBridge.log(TAG + "zoom rocker hook NOT installed: " + t);
        }
    }

    // =====================================================================
    // 1) 5x button
    // =====================================================================
    // NOTE: the adapter constructor is 5 instructions long and gets inlined by ART,
    // so hooking it never fires. getItemCount()/onBindViewHolder() are called
    // virtually by RecyclerView and cannot be inlined, so we patch the adapter's
    // list field ("a") lazily from there.
    private static Object sX5;
    private static Class<?> sValueMap;
    private static boolean sLoggedInject;

    private void hook5xButton(final ClassLoader cl) {
        try {
            final Class<?> keyEnum = XposedHelpers.findClass(C_KEY_ENUM, cl);
            sValueMap = XposedHelpers.findClass(C_KEY_VALUE, cl);
            @SuppressWarnings({"unchecked", "rawtypes"})
            Object x5 = Enum.valueOf((Class<Enum>) keyEnum, KEY_X5);
            sX5 = x5;

            XC_MethodHook ensure = new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam p) {
                    ensureX5(p.thisObject);
                }
            };
            for (String cn : new String[]{C_PILL_ADAPT}) {
                try {
                    Class<?> adapter = XposedHelpers.findClass(cn, cl);
                    XposedBridge.hookAllMethods(adapter, "getItemCount", ensure);
                    XposedBridge.hookAllMethods(adapter, "onBindViewHolder", ensure);
                    XposedBridge.hookAllMethods(adapter, "getItemId", ensure);
                    XposedBridge.log(TAG + "5x hook installed on " + cn);
                } catch (Throwable t) {
                    XposedBridge.log(TAG + "5x hook NOT installed on " + cn + ": " + t);
                }
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + "5x hook NOT installed: " + t);
        }
        hookCapsule(cl);
    }

    /** The visible capsule (.6 1 2 3 10): inject a 5x item right before the list is submitted. */
    private void hookCapsule(final ClassLoader cl) {
        try {
            final Class<?> view = XposedHelpers.findClass(C_LENS_VIEW, cl);
            final Class<?> item = XposedHelpers.findClass(C_LENS_ITEM, cl);
            XposedBridge.hookAllMethods(view, "t", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam p) {
                    try {
                        int li = -1;
                        for (int i = 0; i < p.args.length; i++) {
                            if (p.args[i] instanceof List) { li = i; break; }
                        }
                        if (li < 0) return;
                        List<?> orig = (List<?>) p.args[li];
                        if (orig.isEmpty() || orig.get(0) == null
                                || !orig.get(0).getClass().getName().equals(item.getName())) return;

                        boolean has3 = false, has5 = false;
                        StringBuilder sb = new StringBuilder();
                        for (Object o : orig) {
                            int b = XposedHelpers.getIntField(o, "b");
                            sb.append(b).append(' ');
                            if (b == 3000) has3 = true;
                            if (b == 5000) has5 = true;
                        }
                        if (has5 || !has3) {
                            XposedBridge.log(TAG + "capsule untouched: " + sb);
                            return;
                        }
                        Object newItem = XposedHelpers.newInstance(item, 5000, sX5);
                        List<Object> copy = new ArrayList<>(orig);
                        int at = 0;
                        for (int i = 0; i < copy.size(); i++) {
                            if (XposedHelpers.getIntField(copy.get(i), "b") < 5000) at = i + 1;
                        }
                        copy.add(at, newItem);
                        p.args[li] = copy;
                        XposedBridge.log(TAG + "capsule: 5x injected at " + at + ", was: " + sb);
                    } catch (Throwable t) {
                        XposedBridge.log(TAG + "capsule inject failed: " + t);
                    }
                }
            });
            XposedBridge.log(TAG + "capsule hook installed");
        } catch (Throwable t) {
            XposedBridge.log(TAG + "capsule hook NOT installed: " + t);
        }
    }

    private static void ensureX5(Object adapterObj) {
        try {
            Object cur = XposedHelpers.getObjectField(adapterObj, "a");
            if (!(cur instanceof List)) return;
            List<?> orig = (List<?>) cur;
            if (orig.isEmpty() || orig.contains(sX5)) return;

            boolean zoomPill = false;
            StringBuilder names = new StringBuilder();
            for (Object k : orig) {
                String n = ((Enum<?>) k).name();
                names.append(n.replace("BACK_CAMERA_ZOOM_", "")).append(' ');
                if (n.startsWith("BACK_CAMERA_ZOOM_SHORTCUT_")) zoomPill = true;
            }
            if (!zoomPill) {
                if (!sLoggedInject) XposedBridge.log(TAG + "skipped " + adapterObj.getClass().getName() + ", keys: " + names);
                sLoggedInject = true;
                return;
            }

            final List<Object> copy = new ArrayList<>(orig);
            copy.add(sX5);
            Collections.sort(copy, (x, y) -> {
                int vx = (Integer) XposedHelpers.callStaticMethod(sValueMap, "d", x);
                int vy = (Integer) XposedHelpers.callStaticMethod(sValueMap, "d", y);
                return Integer.compare(vx, vy);
            });
            XposedHelpers.setObjectField(adapterObj, "a", copy);
            XposedBridge.log(TAG + "5x injected into " + adapterObj.getClass().getName() + ". was: " + names);
        } catch (Throwable t) {
            XposedBridge.log(TAG + "5x inject failed: " + t);
        }
    }

    // =====================================================================
    // 2) Smooth zoom ramp on shortcut taps
    // =====================================================================
    private void hookSmoothZoom(final ClassLoader cl) {
        try {
            final Class<?> presenter = XposedHelpers.findClass(C_PRESENTER, cl);
            final Class<?> settingEnum = XposedHelpers.findClass(C_SETTING, cl);
            final Class<?> engineZoom = XposedHelpers.findClass(C_ENGINE_ZOOM, cl);

            @SuppressWarnings({"unchecked", "rawtypes"})
            final Object zoomValueKey = Enum.valueOf((Class<Enum>) settingEnum, "ZOOM_VALUE");

            final Method hMethod = XposedHelpers.findMethodExact(presenter, "h", int.class);

            // If the user pinches / drags while we are ramping, hand control back to them.
            XposedBridge.hookAllMethods(engineZoom, "e", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam p) {
                    if (!sOurZoomCall && sAnim != null && sAnim.isRunning()) sAnim.cancel();
                }
            });

            XposedBridge.hookMethod(hMethod, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(final MethodHookParam p) {
                    if (sPassThrough) return;              // our own replay
                    XposedBridge.log(TAG + "shortcut tap -> " + p.args[0]);
                    if (Looper.myLooper() != Looper.getMainLooper()) return;
                    try {
                        final int target = (Integer) p.args[0];
                        final Object pres = p.thisObject;
                        final Object settings = XposedHelpers.getObjectField(pres, F_PRESENTER_SETTINGS);
                        final int curValue = (Integer) XposedHelpers.callMethod(settings, "d", zoomValueKey);
                        final Object ctrl = XposedHelpers.getObjectField(pres, F_PRESENTER_CAMERA_CTRL);
                        final Object zoomMgr = XposedHelpers.getObjectField(ctrl, F_CTRL_ZOOM_MGR);
                        if (zoomMgr == null) return;

                        float from = (sAnim != null && sAnim.isRunning() && sCurrentRatio > 0)
                                ? sCurrentRatio : curValue / 1000f;
                        final float to = target / 1000f;
                        // same value => let the stock code run (it resets zoom)
                        if (target == curValue || from <= 0f || to <= 0f
                                || Math.abs(to - from) < 0.02f) return;

                        XposedBridge.log(TAG + "ramp " + from + " -> " + to);
                        if (sAnim != null) sAnim.cancel();
                        p.setResult(null);                  // swallow the instant jump

                        final float start = from;
                        final double ln = Math.abs(Math.log(to / start));
                        long dur = (long) Math.max(300, Math.min(900, 250 + 380 * ln));

                        final ValueAnimator va = ValueAnimator.ofFloat(0f, 1f);
                        va.setDuration(dur);
                        va.setInterpolator(t -> t * t * (3f - 2f * t));   // smoothstep ease-in-out
                        va.addUpdateListener(a -> {
                            float t = (Float) a.getAnimatedValue();
                            float ratio = (float) (start * Math.pow(to / start, t));
                            sCurrentRatio = ratio;
                            sOurZoomCall = true;
                            try {
                                XposedHelpers.callMethod(zoomMgr, "e", ratio);
                            } catch (Throwable th) {
                                a.cancel();
                                XposedBridge.log(TAG + "ramp step failed: " + th);
                            } finally {
                                sOurZoomCall = false;
                            }
                        });
                        va.addListener(new AnimatorListenerAdapter() {
                            private boolean cancelled;
                            @Override public void onAnimationCancel(Animator an) { cancelled = true; }
                            @Override public void onAnimationEnd(Animator an) {
                                if (sAnim == an) sAnim = null;
                                sCurrentRatio = -1f;
                                if (cancelled) return;
                                // replay the original handler so the UI (selected button, slider,
                                // zoom text) lands exactly like a normal tap
                                sPassThrough = true;
                                try {
                                    XposedBridge.invokeOriginalMethod(hMethod, pres, new Object[]{target});
                                } catch (Throwable th) {
                                    XposedBridge.log(TAG + "replay failed: " + th);
                                } finally {
                                    sPassThrough = false;
                                }
                            }
                        });
                        sAnim = va;
                        va.start();
                    } catch (Throwable t) {
                        XposedBridge.log(TAG + "smooth zoom fell back to stock: " + t);
                        // do not setResult -> stock behaviour continues
                    }
                }
            });
            XposedBridge.log(TAG + "smooth zoom hook installed");
        } catch (Throwable t) {
            XposedBridge.log(TAG + "smooth zoom hook NOT installed: " + t);
        }
    }
}
