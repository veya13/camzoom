# CamZoomPlus (Samsung Camera 17.0.00.43)

LSPosed module (legacy Xposed API). Scope: com.sec.android.app.camera only.

## What it does
1. Adds a **5x** button: .6 / 1x / 2 / 3 / **5** / 10 (Photo and normal Video).
2. Shortcut taps no longer jump: the zoom glides with an eased exponential ramp
   (300-900 ms depending on distance). Pinch or slider drag cancels the ramp instantly.

## Build
1. Open this folder in Android Studio (Koala or newer), let Gradle sync.
   - The Xposed API is fetched from https://api.xposed.info/ . If your network blocks it,
     download xposed api-82.jar, put it in app/libs/ and replace the dependency with
     `compileOnly files('libs/api-82.jar')`.
2. Build > Build APK(s). Install app-debug.apk.

## Enable
1. KernelSU Next with Zygisk + LSPosed installed.
2. LSPosed > Modules > CamZoomPlus > enable, tick **Camera** in scope.
3. Force stop Camera, reopen.
4. Check LSPosed > Logs > Modules for lines starting with `[CamZoomPlus]`:
   `5x hook installed` and `smooth zoom hook installed`.

## If something does not work
Send the `[CamZoomPlus]` log lines. The module never throws into the camera:
on any mismatch it logs and falls back to stock behaviour.
